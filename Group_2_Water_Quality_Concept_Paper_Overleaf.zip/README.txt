OVERLEAF INSTRUCTIONS

1. Upload all files in this folder to the same Overleaf project:
   - main.tex
   - references.bib
   - mak-logo.jpg

2. Set main.tex as the Main document.

3. Recommended compiler: XeLaTeX.
   In Overleaf: Menu > Settings > Compiler > XeLaTeX.

4. Click Recompile. The bibliography may require two recompilations.

FONT NOTE
The file requests Times New Roman when it is installed. If Overleaf cannot find
that proprietary font, it automatically uses TeX Gyre Termes, the closest
widely available Times-compatible typeface. No line-spacing package is added:
the supplied template's 1.15 baseline stretch is preserved.

EDITING NOTE
Replace only claims that are verified by the NWSC feasibility investigation.
Keep Bugolobi and all deployment points qualified as proposed/subject to NWSC
authorisation until written approval and field evidence confirm them.
